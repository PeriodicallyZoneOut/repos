package com.example.lifecycle;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    EditText edtInput;
    Button btnExit;
    LinearLayout layoutMain;
    String currentColor = "white";
    final String FILE_NAME = "color_state.txt";
    int lastOrientation = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ view
        edtInput = findViewById(R.id.edtInput);
        btnExit = findViewById(R.id.btnExit);
        layoutMain = findViewById(R.id.layoutMain);

        Toast.makeText(this, "onCreate called", Toast.LENGTH_SHORT).show();

        // Đọc màu đã lưu và áp dụng
        loadColorFromFile();
        applyColor(currentColor);

        // Khi nhấn Enter để đổi màu
        edtInput.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                String colorInput = edtInput.getText().toString().trim().toLowerCase();
                switch(colorInput) {
                    case "tu":
                        colorInput="red";
                        break;
                    case "khoa":
                        colorInput="blue";
                        break;
                    case "hoa":
                        colorInput="green";
                        break;
                    case "phuc":
                        colorInput="white";
                        break;
                }
                if (applyColor(colorInput)) {
                    currentColor = colorInput;
                    saveColorToFile(currentColor);
                    Toast.makeText(this, "Changed to " + colorInput, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Invalid color! Try tu, khoa, hoa, phuc", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            return false;
        });

        // Nút Exit
        btnExit.setOnClickListener(v -> {
            saveColorToFile(currentColor);
            finish();
        });
    }

    // Áp dụng màu nền
    private boolean applyColor(String colorName) {
        switch (colorName) {
            case "red":
                layoutMain.setBackgroundColor(Color.RED);
                return true;
            case "green":
                layoutMain.setBackgroundColor(Color.GREEN);
                return true;
            case "blue":
                layoutMain.setBackgroundColor(Color.BLUE);
                return true;
            case "white":
                layoutMain.setBackgroundColor(Color.WHITE);
                return true;
            default:
                return false;
        }
    }

    // Lưu màu hiện tại vào file
    private void saveColorToFile(String color) {
        try {
            FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            fos.write(color.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Đọc màu từ file
    private void loadColorFromFile() {
        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String color = reader.readLine();
            if (color != null) currentColor = color.trim();
            reader.close();
            fis.close();
        } catch (Exception e) {
            currentColor = "white"; // nếu chưa có file
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "onStart called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyColor(currentColor);
        Toast.makeText(this, "onResume called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveColorToFile(currentColor);
        Toast.makeText(this, "onPause called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "onStop called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        loadColorFromFile();
        applyColor(currentColor);
        Toast.makeText(this, "onRestart called", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "onDestroy called", Toast.LENGTH_SHORT).show();
    }

    // ✅ Không tạo lại activity khi xoay
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        String dir;
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            dir = "Landscape (Ngang)";
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            dir = "Portrait (Dọc)";
        } else {
            dir = "Unknown";
        }

        Toast.makeText(this, "Orientation changed: " + dir, Toast.LENGTH_SHORT).show();
    }
}
